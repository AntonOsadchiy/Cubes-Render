#pragma once
#include <GL/glew.h>

class Cube;
class VertexArray;
class IndexBuffer;
class Shader;

class Renderer
{
public:
	void draw(const VertexArray&, const IndexBuffer&, const Shader&) const;
	//friend Cube;
	void drawCube(const Cube&, Shader&) const;
	void clear() const;
};
