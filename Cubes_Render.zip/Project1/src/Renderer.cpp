#include "Renderer.h"
#include "Debug.h"
#include "IndexBuffer.h"
#include "Shader.h"
#include "VertexArray.h"
#include "Cube.h"

void Renderer::draw(const VertexArray & vertex_array, const IndexBuffer & index_buffer, const Shader & shader) const
{
	vertex_array.bind();
	index_buffer.bind();
	shader.bind();

	GLCALL(glDrawElements(GL_TRIANGLES, index_buffer.length(), GL_UNSIGNED_INT, nullptr));
#ifndef NDBUG
	vertex_array.unbind();
	index_buffer.unbind();
	shader.unbind();
#endif
}

void Renderer::drawCube(const Cube & cube, Shader & shader) const
{
	shader.bind();
	shader.setUniform4f("u_Color", cube.color()[0], cube.color()[1], cube.color()[2], cube.color()[3]);
	shader.setUniformmat4f("u_Model", cube.model());
	draw(cube.vertex_array(), cube.index_buffer(), shader);
}


void Renderer::clear() const
{
	GLCALL(glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT));
}
