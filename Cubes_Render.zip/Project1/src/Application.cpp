#define _DISABLE_EXTENDED_ALIGNED_STORAGE 1

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <string>
#include <iostream>
#include <vector>
#include <chrono>

#include "Renderer.h"
#include "Debug.h"
#include "IndexBuffer.h"
#include "VertexBuffer.h"
#include "VertexArray.h"
#include "Shader.h"
#include "Texture.h"
#include "Cube.h"
#include "PhysicWorld.h"

//physics
#include <stdio.h>
#include <btBulletCollisionCommon.h>
#include <btBulletDynamicsCommon.h>

//maths
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"

static const uint32_t X_RES = 1280;
static const uint32_t Y_RES = 720;
static const uint32_t LIGHT_SOURCE_X = 0.0f;
static const uint32_t LIGHT_SOURCE_Y = 5.0f;
static const uint32_t LIGHT_SOURCE_Z = 1.0f;


static float X_MOUSE_POS = 0;
static float Y_MOUSE_POS = 0;
static bool MOUSE_FLAG = false;

static void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
		MOUSE_FLAG = true;
}

static void cursor_position_callback(GLFWwindow* window, double xpos, double ypos)
{
	X_MOUSE_POS = (xpos - X_RES/2)/ X_RES;
	Y_MOUSE_POS = -(ypos - Y_RES)/ Y_RES;
}

int main(void)
{

	GLFWwindow* window;

	// Initialize the library
	if(!glfwInit())
		return -1;

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Create a windowed mode window and its OpenGL context
	window = glfwCreateWindow(X_RES, Y_RES, "Hello World", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	glfwSetCursorPosCallback(window, cursor_position_callback);
	glfwSetMouseButtonCallback(window, mouse_button_callback);
	glfwSetInputMode(window, GLFW_STICKY_MOUSE_BUTTONS, GLFW_TRUE);

	// Make the window's context current
	glfwMakeContextCurrent(window);

	//glfwSwapInterval(1);//V-Sync

	//linking with modern OpenGL
	if (glewInit() != GLEW_OK)
		std::cout << "error" << std::endl;
	{
		float positions[] = {
			-2.0f, -2.0f, 0.0f, 0.0f,//0
			-2.0f,  2.0f, 0.0f, 1.0f,//1
			 2.0f,  2.0f, 1.0f, 1.0f,//2
			 2.0f, -2.0f, 1.0f, 0.0f,//3
		};
		size_t indices[] = { 0,1,2, 2,3,0 };

		//blending
		GLCALL(glEnable(GL_BLEND));
		GLCALL(glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA));
		GLCALL(glEnable(GL_DEPTH_TEST));

		VertexArray va;
		//setting up an vertex buffer
		VertexBuffer vb(positions, std::size(positions) * sizeof(float));

		//setting the layout to bind with the vertex buffer in the vertex array
		VBLayout layout;
		layout.push<float>(2);
		layout.push<float>(2);
		va.addBuffer(vb, layout);

		//setting up an index buffer
		IndexBuffer ib(indices, std::size(indices));

		// Model View Projection Matrices
		glm::mat4 projection_matrix = glm::perspective(glm::radians(45.0f), (float)X_RES / Y_RES, 0.1f, 100.0f);
		glm::mat4 view_matrix(1.0f);
		view_matrix = glm::translate(view_matrix, glm::vec3(0.f, -3.0f, -10.0f));
		glm::mat4 model_matrix(1.0f);
		model_matrix = glm::rotate(model_matrix, glm::radians(-90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		model_matrix = glm::translate(model_matrix, glm::vec3(0.f, 0.0f, 0.0f));

		//setting up shaders and setting uniforms
		Shader plat_shader("res/shaders/Basic.shader");
		plat_shader.bind();
		plat_shader.setUniform4f("u_LigthColor", 1.0f, 1.0f, 1.0f, 1.0f);
		plat_shader.setUniform4f("u_Color", 1.0f, 0.0f, 1.0f, 1.0f);
		plat_shader.setUniformmat4f("u_Model", model_matrix);
		plat_shader.setUniformmat4f("u_View", view_matrix);
		plat_shader.setUniformmat4f("u_Projection", projection_matrix);
		//setting up texture
		Texture texture("res/textures/grass.png");
		texture.bind();
		plat_shader.setUniform1i("u_Texture", 0);//has to match texture.bind parameter

		Shader cube_shader("res/shaders/cube.shader");
		cube_shader.bind();
		cube_shader.setUniform4f("u_LigthColor", 1.0f, 1.0f, 1.0f, 1.0f);
		cube_shader.setUniform4f("u_LightPos", LIGHT_SOURCE_X, LIGHT_SOURCE_Y, LIGHT_SOURCE_Z, 0.0f);
		cube_shader.setUniform4f("u_Color", 1.0f, 0.0f, 1.0f, 1.0f);
		cube_shader.setUniformmat4f("u_View", view_matrix);
		cube_shader.setUniformmat4f("u_Projection", projection_matrix);

		PhysicsWorld world;

		Renderer renderer;

		float g = 0.0f;
		float increment = 0.005f;
		float min_fps = 1000.f;
		// Loop until the user closes the window
		while (!glfwWindowShouldClose(window))
		{
			auto start = std::chrono::high_resolution_clock::now();

			// Render here
			renderer.clear();

			if (MOUSE_FLAG) 
			{
				world.addCube(15*X_MOUSE_POS, 15*9/16 * Y_MOUSE_POS, 0.0f);
				MOUSE_FLAG = false;
			}

			//platform rendering
			plat_shader.bind();
			plat_shader.setUniform4f("u_Color", 1.0f, g, 1.0f, 1.0f);
			renderer.draw(va, ib, plat_shader);
			g += increment;
			if (g > 1.0f || g < 0.0f)
			{
				increment = -increment;
				g += increment;
			}

			world.simulateStep();
			
			//cube rendering
			for (uint32_t i=0; i< world.cubes().size(); i++)
				renderer.drawCube(world.cubes()[i], cube_shader);

			// Swap front and back buffers
			glfwSwapBuffers(window);

			// Poll for and process events
			glfwPollEvents();

			auto finish = std::chrono::high_resolution_clock::now();

			float fps = 1.f / std::chrono::duration<double>(finish - start).count();
			std::cout << (min_fps = min_fps < fps? min_fps = fps : fps ) << std::endl;;
		}
		std::cout << "min fps was: " << min_fps << std::endl;
	}

	glfwTerminate();
	return 0;
}