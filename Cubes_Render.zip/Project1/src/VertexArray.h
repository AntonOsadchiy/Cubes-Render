#pragma once

#include "VertexBuffer.h"
#include "VBLayout.h"


class VertexArray
{
private:
	unsigned int _id;

public:
	VertexArray();
	inline VertexArray(unsigned int id) : _id(id) {}
	inline VertexArray(const VertexArray& other) : _id(other._id) {}
	~VertexArray();

	void addBuffer(const VertexBuffer&, const VBLayout&);

	void bind() const;
	void unbind() const;

};
