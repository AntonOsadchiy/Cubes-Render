#pragma once
#include <GL/glew.h>

#define ASSERT(x) if (!(x)) __debugbreak();
#define GLCALL(x) GLClearError();\
x;\
ASSERT(GLLogCall(#x, __FILE__, __LINE__))

//clears all errors left in the glGetError()
void GLClearError();
//calls function f, returns false if any arrors occured, otherwise true
bool GLLogCall(const char* f, const char* file, int line);