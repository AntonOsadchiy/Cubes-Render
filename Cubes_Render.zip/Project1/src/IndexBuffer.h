#pragma once

class IndexBuffer
{
private:
	unsigned int _id;
	unsigned int _len;
public:
	IndexBuffer(const unsigned int*, unsigned int);
	~IndexBuffer();

	void bind() const;
	void unbind() const;

	inline unsigned int length() const { return _len; }
};