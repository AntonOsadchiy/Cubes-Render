#include "VertexArray.h"
#include "Debug.h"

VertexArray::VertexArray()
{
	GLCALL(glGenVertexArrays(1, &_id));
}

VertexArray::~VertexArray()
{
	GLCALL(glDeleteVertexArrays(1, &_id));
}

void VertexArray::addBuffer(const VertexBuffer& vb, const VBLayout& layout)
{
	bind();
	vb.bind();
	unsigned int offset = 0;
	for (unsigned int i = 0; i < layout.elements().size(); i++)
	{
		const Element& element = layout.elements()[i];
		GLCALL(glEnableVertexAttribArray(i));
		GLCALL(glVertexAttribPointer(i, element.len, element.type, element.normalized, layout.stride(), (void*)offset));
		offset += element.len * sizeofGLType(element.type);
	}
}

void VertexArray::bind() const
{
	GLCALL(glBindVertexArray(_id));
}

void VertexArray::unbind() const
{
	GLCALL(glBindVertexArray(0));
}
