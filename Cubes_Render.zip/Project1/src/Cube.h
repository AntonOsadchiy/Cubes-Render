#pragma once
#include <array>

#include "VertexArray.h"
#include "IndexBuffer.h"
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"

#include <time.h>

#include <stdio.h>
#include <btBulletCollisionCommon.h>
#include <btBulletDynamicsCommon.h>

class Cube
{
private:
	glm::mat4 _model;
	glm::vec4 _color;
	VertexArray _va;
	IndexBuffer _ib;
	void genArray();


	time_t _spawn_time;
	static const time_t MAX_TIME = 20;

	btCollisionObject* _bt_body;
	uint32_t _collisionIndex;
public:
	const static float CUBE_MASS;

	static std::array<float, 8 * 3 * 6> vertices;
	static std::array<unsigned int, 6 * 2 * 3> indices;

	Cube();
	Cube(float x, float y, float z);
	~Cube();

	Cube(const Cube & other);

	Cube operator=(const Cube&);

	inline const glm::mat4& model() const { return _model; }
	inline glm::mat4& model() { return _model; }
	inline const glm::vec4& color() const { return _color; }
	inline glm::vec4& color() { return _color; }

	inline const VertexArray& vertex_array() const{ return _va; }
	inline const IndexBuffer& index_buffer() const{ return _ib; }

	inline uint32_t& collisionIndex() { return _collisionIndex; }
	inline btCollisionObject*& bt_body() { return _bt_body; }

	inline bool shouldDespawn()
	{
		time_t current;
		time(&current);
		return (current - _spawn_time) > MAX_TIME;
		//return false;
	}
};