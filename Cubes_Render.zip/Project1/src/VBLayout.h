#pragma once

#include <vector>
#include <GL/glew.h>

struct Element
{
	unsigned int type;
	unsigned int len;
	unsigned int normalized;
};

unsigned int sizeofGLType(unsigned int type);

class VBLayout
{
private:
	std::vector<Element> _elements;
	unsigned int _stride;

public:
	VBLayout() :_stride(0) {}
	~VBLayout() {}

	template<typename T>
	void push(unsigned int len) { static_assert(false); }

	template<>
	void push<float>(unsigned int len)
	{
		_elements.push_back({ GL_FLOAT, len, GL_FALSE });
		_stride += len * sizeofGLType(GL_FLOAT);
	}

	template<>
	void push<unsigned int>(unsigned int len)
	{
		_elements.push_back({ GL_UNSIGNED_INT, len, GL_FALSE });
		_stride += len * sizeofGLType(GL_UNSIGNED_INT);
	}

	template<>
	void push<unsigned char>(unsigned int len)
	{
		_elements.push_back({ GL_UNSIGNED_BYTE, len, GL_TRUE });
		_stride += len * sizeofGLType(GL_UNSIGNED_BYTE);
	}

	inline const std::vector<Element>& elements() const { return _elements; }
	inline unsigned int stride() const { return _stride; }
};