#include "PhysicWorld.h"

#include "glm/fwd.hpp"
#include "glm/gtc/quaternion.hpp"
#include "glm/gtx/quaternion.hpp"

const float PhysicsWorld::SIMULATION_SPEED = 1.f;

PhysicsWorld::PhysicsWorld():
	_collisionConfiguration(new btDefaultCollisionConfiguration()),
	_dispatcher(new btCollisionDispatcher(_collisionConfiguration)),
	_overlappingPairCache(new btDbvtBroadphase()),
	_solver(new btSequentialImpulseConstraintSolver()),
	_dynamicsWorld(new btDiscreteDynamicsWorld(_dispatcher, _overlappingPairCache, _solver, _collisionConfiguration)),
	_collisionShapes(btAlignedObjectArray<btCollisionShape*>())
{
	_cubes.reserve(10);
	_dynamicsWorld->setGravity(btVector3(0.f, -9.8f, 0.f));

	//adding a static platform
	btCollisionShape* groundShape = new btBoxShape(btVector3(2.f, 0.01f, 2.f));

	_collisionShapes.push_back(groundShape);

	btTransform groundTransform;
	groundTransform.setIdentity();
	groundTransform.setOrigin(btVector3(0, 0, 0));

	btScalar mass(0.);

	//rigidbody is dynamic if and only if mass is non zero, otherwise static
	bool isDynamic = (mass != 0.f);

	btVector3 localInertia(0, 0, 0);
	if (isDynamic)
		groundShape->calculateLocalInertia(mass, localInertia);

	//using motionstate is optional, it provides interpolation capabilities, and only synchronizes 'active' objects
	btDefaultMotionState* myMotionState = new btDefaultMotionState(groundTransform);
	btRigidBody::btRigidBodyConstructionInfo rbInfo(mass, myMotionState, groundShape, localInertia);
	btRigidBody* body = new btRigidBody(rbInfo);

	//add the body to the dynamics world
	_dynamicsWorld->addRigidBody(body);
}

PhysicsWorld::PhysicsWorld(float g_x, float g_y, float g_z):
	_collisionConfiguration(new btDefaultCollisionConfiguration()),
	_dispatcher(new btCollisionDispatcher(_collisionConfiguration)),
	_overlappingPairCache(new btDbvtBroadphase()),
	_solver(new btSequentialImpulseConstraintSolver()),
	_dynamicsWorld(new btDiscreteDynamicsWorld(_dispatcher, _overlappingPairCache, _solver, _collisionConfiguration))
{

	_dynamicsWorld->setGravity(btVector3(g_x, g_y, g_y));

	//adding a static platform
	btCollisionShape* groundShape = new btBoxShape(btVector3(btScalar(50.), btScalar(0.01f), btScalar(50.)));

	_collisionShapes.push_back(groundShape);

	btTransform groundTransform;
	groundTransform.setIdentity();
	groundTransform.setOrigin(btVector3(0, 0, 0));

	btScalar mass(0.);

	//rigidbody is dynamic if and only if mass is non zero, otherwise static
	bool isDynamic = (mass != 0.f);

	btVector3 localInertia(0, 0, 0);
	if (isDynamic)
		groundShape->calculateLocalInertia(mass, localInertia);

	//using motionstate is optional, it provides interpolation capabilities, and only synchronizes 'active' objects
	btDefaultMotionState* myMotionState = new btDefaultMotionState(groundTransform);
	btRigidBody::btRigidBodyConstructionInfo rbInfo(mass, myMotionState, groundShape, localInertia);
	btRigidBody* body = new btRigidBody(rbInfo);

	//add the body to the dynamics world
	_dynamicsWorld->addRigidBody(body);
}

PhysicsWorld::~PhysicsWorld()
{
	delete _collisionConfiguration;
	delete _dispatcher;
	delete _overlappingPairCache;
	delete _solver;
	delete _dynamicsWorld;
	_collisionShapes.clear();
}


void PhysicsWorld::addCube(float x, float y, float z)
{
	_cubes.emplace_back(x, y, z);

	btCollisionShape* colShape = new btBoxShape(btVector3(0.2f, 0.2f, 0.2f));
	_collisionShapes.push_back(colShape);

	//Create Dynamic Objects
	btTransform startTransform;
	startTransform.setIdentity();

	btVector3 localInertia(0, 0, 0);
	colShape->calculateLocalInertia(Cube::CUBE_MASS, localInertia);
	startTransform.setOrigin(btVector3(x, y, z));
	btDefaultMotionState* myMotionState = new btDefaultMotionState(startTransform);
	btRigidBody* body = new btRigidBody(btRigidBody::btRigidBodyConstructionInfo(Cube::CUBE_MASS, myMotionState, colShape, localInertia));
	_dynamicsWorld->addRigidBody(body);

	//link Cube object with btRigidBody it represents
	_cubes[_cubes.size() - 1].collisionIndex() = _dynamicsWorld->getNumCollisionObjects() - 1;
	_cubes[_cubes.size() - 1].bt_body() = _dynamicsWorld->getCollisionObjectArray()[_dynamicsWorld->getNumCollisionObjects() - 1];
}

//cleans up memory
void PhysicsWorld::removeCube(uint32_t index)
{
	int i = _cubes[index].collisionIndex();

	btCollisionObject* obj = _dynamicsWorld->getCollisionObjectArray()[i];
	_dynamicsWorld->removeCollisionObject(obj);

	btRigidBody* body = btRigidBody::upcast(obj);
	if (body && body->getMotionState())
		delete body->getMotionState();

	delete obj;

	_cubes.erase(_cubes.begin() + index);
	for (uint32_t i = index; i < _cubes.size(); i++)
		_cubes[i].collisionIndex()--;
}


void PhysicsWorld::simulateStep()
{
	//frequency
	_dynamicsWorld->stepSimulation(SIMULATION_SPEED * 1.f / 60.f, 10);

	for (int i = _cubes.size() - 1; i < _cubes.size(); i--)
	{
	
		btCollisionObject* obj = _cubes[i].bt_body();
		btRigidBody* body = btRigidBody::upcast(obj);
		btTransform trans;
		if (body && body->getMotionState())
			body->getMotionState()->getWorldTransform(trans);
		else
			trans = obj->getWorldTransform();

		if (_cubes[i].shouldDespawn() || trans.getOrigin().getY() < 0)
		{
			removeCube(i);
		}	
		else
		{
			glm::vec3 translation(float(trans.getOrigin().getX()), float(trans.getOrigin().getY()), float(trans.getOrigin().getZ()));
			_cubes[i].model() = glm::translate(glm::mat4(1.f), translation); 
			//rotation
			const btVector3& axis = trans.getRotation().getAxis();
			_cubes[i].model() = glm::rotate(_cubes[i].model(), float(trans.getRotation().getAngle()),
				glm::vec3(float(axis.getX()),
				float(axis.getY()),
				float(axis.getZ())));
		}
	}
}


