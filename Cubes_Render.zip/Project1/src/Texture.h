#pragma once
#include "Debug.h"
#include "vendor/stb_image.h"
#include <string>

class Texture
{
private:
	unsigned int _id;
	std::string _filepath;
	unsigned char* _local_buffer;
	int _width, _height, _bits_per_pixel;
public:
	Texture(const std::string& );
	~Texture();

	void bind(unsigned int slot = 0) const;
	void unbind() const;

	inline int width() const { return _width; }
	inline int height() const { return _height; }

};