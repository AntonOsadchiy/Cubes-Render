#pragma once

#include "Cube.h"

#include <stdio.h>
#include <btBulletCollisionCommon.h>
#include <btBulletDynamicsCommon.h>
#include <vector>

class PhysicsWorld
{
private:
	std::vector<Cube> _cubes;

	btDefaultCollisionConfiguration* _collisionConfiguration;
	btCollisionDispatcher* _dispatcher;
	btBroadphaseInterface* _overlappingPairCache;
	btSequentialImpulseConstraintSolver* _solver;
	
	btAlignedObjectArray<btCollisionShape*> _collisionShapes;

	PhysicsWorld(const PhysicsWorld&);
public:
	static const float SIMULATION_SPEED; 
	btDiscreteDynamicsWorld* _dynamicsWorld;
	PhysicsWorld();
	PhysicsWorld(float g_x, float g_y, float g_z);
	~PhysicsWorld();

	inline const std::vector<Cube>& cubes() const { return _cubes; }
	inline void addCube() { addCube(0.f, 10.0f, 0.f); }
	void addCube(float x, float y, float z);
	void removeCube(uint32_t index);

	void simulateStep();// { _dynamicsWorld->stepSimulation(1.f / 60.f, 10); }
};