#include "Debug.h"
#include <iostream>

void GLClearError()
{
	while (GLenum error = glGetError())
		std::cout << "OpenGL error:" << error;
}


bool GLLogCall(const char* f, const char* file, int line)
{
	while (GLenum error = glGetError())
	{
		std::cout << "OpenGL error:" << error << " ,"
			<< f << ':' << file << ':' << line << std::endl;
		return false;
	}
	return true;
}
