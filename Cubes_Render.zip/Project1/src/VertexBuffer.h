#pragma once

class VertexBuffer
{
private:
	unsigned int _id;
public:
	VertexBuffer(const void*, unsigned int);
	~VertexBuffer();

	void bind() const;
	void unbind() const;
};