#pragma once
#include <string>
#include <unordered_map>
#include "glm/glm.hpp"

struct ShaderProgramSource
{
	std::string vertexShader;
	std::string fragmentShader;
};

class Shader
{
private:
	std::string _filepath;
	unsigned int _id;

	int getUniformLocation(const std::string&);

	//creates a program, then compiles shaders  given as strings and attaches to program
	unsigned int createShader(const std::string& , const std::string& );
	//compiles shaders with error handling
	unsigned int compileShader(const std::string& , size_t );
	ShaderProgramSource parseShader(const std::string&);

	//caching for uniforms
	std::unordered_map<std::string, int> _uniform_location_cache;
public:
	Shader(const std::string&);
	~Shader();

	void bind() const;
	void unbind() const;

	//set uniforms
	void setUniform1i(const std::string&, int);
	void setUniform4f(const std::string&, float, float, float, float);
	void setUniformmat4f(const std::string&, const glm::mat4&);

};