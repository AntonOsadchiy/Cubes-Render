#include "Shader.h"
#include "Debug.h"

#include <iostream>
#include <fstream>
#include <sstream>


Shader::Shader(const std::string & filepath):_filepath(filepath), _id(0)
{
	ShaderProgramSource source(parseShader(filepath));
	_id = createShader(source.vertexShader, source.fragmentShader);
}

Shader::~Shader()
{
	GLCALL(glDeleteProgram(_id));
}

void Shader::bind() const
{
	GLCALL(glUseProgram(_id));
}

void Shader::unbind() const
{
	GLCALL(glUseProgram(0));
}


void Shader::setUniform1i(const std::string & name, int n)
{
	GLCALL(glUniform1i(getUniformLocation(name), n));
}

void Shader::setUniform4f(const std::string & name, float f1, float f2, float f3, float f4)
{
	GLCALL(glUniform4f(getUniformLocation(name), f1, f2, f3, f4));
}

void Shader::setUniformmat4f(const std::string & name, const glm::mat4 & matrix)
{
	GLCALL(glUniformMatrix4fv(getUniformLocation(name), 1, GL_FALSE, &matrix[0][0]));
}


int Shader::getUniformLocation(const std::string & name)
{
	if (_uniform_location_cache.find(name) != _uniform_location_cache.end())
		return _uniform_location_cache[name];

	GLCALL(int location = glGetUniformLocation(_id, name.c_str()));
#ifndef NDBUG
	if (location == -1)
		std::cout << "Warning: uniform " << name << " doesn't exist" << std::endl;
#endif
	_uniform_location_cache[name] = location;
	return location;
}


ShaderProgramSource Shader::parseShader(const std::string& filepath)
{
	std::ifstream stream(_filepath);
	enum class ShaderType
	{
		NONE = -1, VERTEX = 0, FRAGMENT = 1
	};

	std::string line;
	std::stringstream ss[2];
	ShaderType type = ShaderType::NONE;
	while (getline(stream, line))
	{
		if (line.find("#shader") != std::string::npos)
		{
			if (line.find("vertex") != std::string::npos)
				type = ShaderType::VERTEX;
			else if (line.find("fragment") != std::string::npos)
				type = ShaderType::FRAGMENT;
		}
		else
		{
			ss[(int)type] << line << '\n';
		}
	}
	//std::cout << ss[0].str() << std::endl;
	//std::cout << ss[1].str() << std::endl;
	return ShaderProgramSource{ ss[0].str(), ss[1].str() };
}

unsigned int Shader::compileShader(const std::string& source, size_t type)
{
	GLCALL(size_t id = glCreateShader(type));
	const char* src = source.c_str();
	GLCALL(glShaderSource(id, 1, &src, nullptr));
	GLCALL(glCompileShader(id));
	//error handling
#ifndef NDBUG
	int result;
	GLCALL(glGetShaderiv(id, GL_COMPILE_STATUS, &result));
	if (result == GL_FALSE)
	{
		int length;
		GLCALL(glGetShaderiv(id, GL_INFO_LOG_LENGTH, &length));
		char* message = (char*)alloca(length * sizeof(char));
		GLCALL(glGetShaderInfoLog(id, length, &length, message));
		std::cout << "Failed to compile" << std::endl;
		std::cout << message << std::endl;
		GLCALL(glDeleteShader(id));
		return 0;
	}
#endif // !NDBUG

	return id;
}


unsigned int Shader::createShader(const std::string& vertexShader, const std::string& fragmentShader)
{
	GLCALL(size_t program = glCreateProgram());
	size_t vs = compileShader(vertexShader, GL_VERTEX_SHADER);
	size_t fs = compileShader(fragmentShader, GL_FRAGMENT_SHADER);

	GLCALL(glAttachShader(program, vs));
	GLCALL(glAttachShader(program, fs));
	GLCALL(glLinkProgram(program));
	GLCALL(glValidateProgram(program));

	GLCALL(glDeleteShader(vs));
	GLCALL(glDeleteShader(fs));

	return program;
}