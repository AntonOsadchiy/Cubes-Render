#include "Cube.h"
#include "VertexBuffer.h"
#include "VBLayout.h"

const float Cube::CUBE_MASS = 0.008f;

std::array<float, 8*3*6> Cube::vertices = {
	-0.2f, -0.2f, -0.2f,  0.0f, -1.0,  0.0f,//0 0-bottom
	-0.2f, -0.2f, -0.2f,  0.0f,  0.0, -1.0f,//1 0-far
	-0.2f, -0.2f, -0.2f, -1.0f,  0.0,  0.0f,//2 0-left

	-0.2f, -0.2f,  0.2f,  0.0f, -1.0, -1.0f,//3 1-bottom
	-0.2f, -0.2f,  0.2f, -1.0f,  0.0,  0.0f,//4 1-left
	-0.2f, -0.2f,  0.2f,  0.0f,  0.0,  1.0f,//5 1-close

	 0.2f, -0.2f,  0.2f,  0.0f, -1.0,  0.0f,//6 2-bottom
	 0.2f, -0.2f,  0.2f,  0.0f,  0.0,  1.0f,//7 2-close
	 0.2f, -0.2f,  0.2f,  1.0f,  0.0,  0.0f,//8 2-right

	 0.2f, -0.2f, -0.2f,  0.0f, -1.0,  0.0f,//9 3-bottom
	 0.2f, -0.2f, -0.2f,  0.0f,  0.0, -1.0f,//10 3-far
	 0.2f, -0.2f, -0.2f,  1.0f,  0.0,  0.0f,//11 3-right


	-0.2f,  0.2f, -0.2f,  0.0f,  1.0,  0.0f,//12 4-top
	-0.2f,  0.2f, -0.2f, -1.0f,  0.0,  0.0f,//13 4-left 
	-0.2f,  0.2f, -0.2f,  0.0f,  0.0, -1.0f,//14 4-far

	-0.2f,  0.2f,  0.2f,  0.0f,  1.0,  0.0f,//15 5-top
	-0.2f,  0.2f,  0.2f, -1.0f,  0.0,  0.0f,//16 5-left
	-0.2f,  0.2f,  0.2f,  0.0f,  0.0,  1.0f,//17 5-close

	 0.2f,  0.2f,  0.2f,  0.0f,  1.0,  0.0f,//18 6-top
	 0.2f,  0.2f,  0.2f,  0.0f,  0.0,  1.0f,//19 6-close
	 0.2f,  0.2f,  0.2f,  1.0f,  0.0,  0.0f,//20 6-right

	 0.2f,  0.2f, -0.2f,  0.0f,  1.0,  0.0f,//21 7-top
	 0.2f,  0.2f, -0.2f,  1.0f,  0.0,  0.0f,//22 7-right
	 0.2f,  0.2f, -0.2f,  0.0f,  0.0, -1.0f,//23 7-far
	};

std::array<unsigned int, 6*3*2> Cube::indices = { 
	0,3,6, 6,9,0,//bottom
	5,7,17, 17,19,7,//close
	2,4,13, 13,16,4,//left
	11,8,20, 20,22,11,//right
	1,10,23, 23,14,1,//far
	12,15,18, 18,21,12//top
	};


void Cube::genArray()
{
	VertexBuffer vb_cube(Cube::vertices.data(), sizeof(float) * 8 * 3 * 6);
	VBLayout layout_cube;
	layout_cube.push<float>(3);
	layout_cube.push<float>(3);
	_va.addBuffer(vb_cube, layout_cube);
	_va.unbind();
	return;
}


Cube::Cube() :
	_model(1.0f), _color(rand() / (RAND_MAX + 1.0), rand() / (RAND_MAX + 1.0), rand() / (RAND_MAX + 1.0), 1.0f),
	_ib(indices.data(), 6*3*2),
	_collisionIndex(0),
	_bt_body(nullptr)
{
	genArray();
	time(&_spawn_time);
}

Cube::Cube(float x, float y, float z) :
	_model(glm::translate(glm::mat4(1.0f), glm::vec3(x, y, z))),
	_color(rand() / (RAND_MAX + 1.0), rand() / (RAND_MAX + 1.0), rand() / (RAND_MAX + 1.0), 1.0f),
	_ib(indices.data(), 6 * 3 * 2),
	_collisionIndex(0),
	_bt_body(nullptr)
{
	genArray();
	time(&_spawn_time);
}

Cube::~Cube()
{
}

Cube::Cube(const Cube & other):
	_model(other._model),
	_color(other._color),
	_ib(indices.data(), 6 * 3 * 2),
	_spawn_time(other._spawn_time),
	_collisionIndex(other._collisionIndex),
	_bt_body(other._bt_body)
{
	//time(&_spawn_time);
	genArray();
}

Cube Cube::operator=(const Cube & other)
{
	_model = other._model;
	_color = other._color;
	_spawn_time = other._spawn_time;

	//_spawned = other._spawned;
	_collisionIndex = other._collisionIndex;
	_bt_body = other._bt_body;
	return *this;
}
