#include "IndexBuffer.h"
#include "Debug.h"

IndexBuffer::IndexBuffer(const unsigned int * data, unsigned int length):_len(length)
{
	GLCALL(glGenBuffers(1, &_id));
	GLCALL(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _id));
	GLCALL(glBufferData(GL_ELEMENT_ARRAY_BUFFER, length * sizeof(unsigned int), data, GL_STATIC_DRAW));
}

IndexBuffer::~IndexBuffer()
{
	GLCALL(glDeleteBuffers(1, &_id));
}

void IndexBuffer::bind() const
{
	GLCALL(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _id));
}

void IndexBuffer::unbind() const
{
	GLCALL(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0));
}